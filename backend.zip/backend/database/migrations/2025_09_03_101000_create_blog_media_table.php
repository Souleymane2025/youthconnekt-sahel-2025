<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('blog_media', function (Blueprint $table) {
            $table->id();
            $table->foreignId('blog_id')->constrained('blogs')->onDelete('cascade');
            $table->string('type', 20); // image | video | other
            $table->string('path');
            $table->string('mime_type', 120)->nullable();
            $table->unsignedBigInteger('size')->nullable(); // bytes
            $table->unsignedInteger('duration')->nullable(); // seconds for video (optional)
            $table->integer('position')->default(0);
            $table->string('caption', 255)->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->index(['blog_id','position']);
            $table->index('type');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('blog_media');
    }
};
