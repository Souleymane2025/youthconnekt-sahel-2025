<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('site_assets', function (Blueprint $table) {
            $table->id();
            $table->string('type', 60); // site_logo, favicon, partner_logo, sponsor_logo, banner_home, gallery, etc.
            $table->string('path');
            $table->string('original_name')->nullable();
            $table->string('mime_type',120)->nullable();
            $table->unsignedBigInteger('size')->nullable();
            $table->unsignedInteger('width')->nullable();
            $table->unsignedInteger('height')->nullable();
            $table->string('alt',255)->nullable();
            $table->string('title',255)->nullable();
            $table->integer('position')->default(0);
            $table->boolean('is_active')->default(true);
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->index(['type','is_active']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('site_assets');
    }
};
