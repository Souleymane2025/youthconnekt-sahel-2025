<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Participant extends Model
{
    use HasFactory;

    protected $fillable = [
        'unique_id',
        'type',
        'first_name',
        'last_name',
        'email',
        'phone',
        'date_of_birth',
        'gender',
        'country',
        'city',
        'address',
        'occupation',
        'organization',
        'position',
        'profile_image',
        'passport_image',
        'id_card_image',
        'passport_number',
        'id_card_number',
        'motivation',
        'status',
        'email_confirmed',
        'confirmation_token'
    ];

    protected $casts = [
        'date_of_birth' => 'date',
        'email_confirmed' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'confirmed_at' => 'datetime'
    ];

    protected static function boot()
    {
        parent::boot();
        
        static::creating(function ($participant) {
            if (empty($participant->unique_id)) {
                $participant->unique_id = 'YC' . date('Y') . strtoupper(Str::random(8));
            }
            if (empty($participant->confirmation_token)) {
                $participant->confirmation_token = Str::random(60);
            }
        });
    }

    public function sessions()
    {
        return $this->hasMany(ParticipantSession::class);
    }

    public function emailLogs()
    {
        return $this->hasMany(EmailLog::class);
    }

    public function getFullNameAttribute()
    {
        return $this->first_name . ' ' . $this->last_name;
    }

    public function isNational()
    {
        return $this->type === 'national';
    }

    public function isInternational()
    {
        return $this->type === 'international';
    }

    public function isPending()
    {
        return $this->status === 'pending';
    }

    public function isConfirmed()
    {
        return $this->status === 'confirmed';
    }

    public function canReceiveBadge()
    {
        return $this->isConfirmed() && $this->email_confirmed;
    }

    public function scopeNational($query)
    {
        return $query->where('type', 'national');
    }

    public function scopeInternational($query)
    {
        return $query->where('type', 'international');
    }

    public function scopeConfirmed($query)
    {
        return $query->where('status', 'confirmed');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }
}
