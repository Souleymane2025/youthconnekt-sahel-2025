<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class SiteAsset extends Model
{
    use HasFactory;

    protected $fillable = [
        'type', 'path', 'original_name', 'mime_type', 'size', 'width', 'height', 'alt', 'title', 'position', 'is_active', 'meta'
    ];

    protected $casts = [
        'meta' => 'array',
        'is_active' => 'boolean'
    ];

    protected $appends = ['url'];

    public function getUrlAttribute(): string
    {
        if (str_starts_with($this->path, 'http://') || str_starts_with($this->path, 'https://')) {
            return $this->path;
        }
        return asset('storage/' . $this->path);
    }

    protected static function booted()
    {
        static::deleting(function (SiteAsset $asset) {
            if ($asset->path && !str_starts_with($asset->path,'http') && Storage::disk('public')->exists($asset->path)) {
                Storage::disk('public')->delete($asset->path);
            }
        });
    }
}
