<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class BlogMedia extends Model
{
    use HasFactory;

    protected $fillable = [
        'blog_id', 'type', 'path', 'mime_type', 'size', 'duration', 'position', 'caption', 'meta'
    ];

    protected $casts = [
        'meta' => 'array'
    ];

    protected $appends = ['url'];

    public function blog()
    {
        return $this->belongsTo(Blog::class);
    }

    public function getUrlAttribute(): string
    {
        if (str_starts_with($this->path, 'http://') || str_starts_with($this->path, 'https://')) {
            return $this->path; // external URL
        }
        return asset('storage/' . $this->path);
    }

    protected static function booted()
    {
        static::deleting(function (BlogMedia $media) {
            if ($media->path && Storage::disk('public')->exists($media->path)) {
                Storage::disk('public')->delete($media->path);
            }
        });
    }
}
