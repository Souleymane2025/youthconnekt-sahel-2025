<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ParticipantSession extends Model
{
    use HasFactory;

    protected $fillable = [
        'participant_id',
        'session_name',
        'session_date'
    ];

    protected $casts = [
        'session_date' => 'date'
    ];

    public function participant()
    {
        return $this->belongsTo(Participant::class);
    }
}
