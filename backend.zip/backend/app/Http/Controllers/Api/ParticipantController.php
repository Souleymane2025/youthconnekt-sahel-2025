<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Participant;
use App\Models\EmailLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class ParticipantController extends Controller
{
    public function register(Request $request)
    {
        try {
            // Validation des données
            $validator = Validator::make($request->all(), [
                'type' => 'required|in:national,international',
                'first_name' => 'required|string|max:100',
                'last_name' => 'required|string|max:100',
                'email' => 'required|email|unique:participants,email',
                'phone' => 'required|string|max:20',
                'date_of_birth' => 'required|date|before:today',
                'gender' => 'required|in:M,F,Autre',
                'country' => 'required|string|max:100',
                'city' => 'required|string|max:100',
                'occupation' => 'required|string|max:100',
                'motivation' => 'required|string|max:500',
                'profile_image' => 'required|image|mimes:jpeg,jpg,png|max:5120', // 5MB
                'id_card_number' => 'required_if:type,national|string|max:50',
                'id_card_image' => 'required_if:type,national|image|mimes:jpeg,jpg,png|max:5120',
                'passport_number' => 'required_if:type,international|string|max:50',
                'passport_image' => 'required_if:type,international|image|mimes:jpeg,jpg,png|max:5120',
                'terms' => 'required|accepted'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Données invalides',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Vérifier si l'email existe déjà
            if (Participant::where('email', $request->email)->exists()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cet email est déjà utilisé pour une inscription.'
                ], 409);
            }

            // Upload des fichiers
            $profileImagePath = null;
            $documentImagePath = null;

            if ($request->hasFile('profile_image')) {
                $profileImagePath = $request->file('profile_image')->store('participants/profiles', 'public');
            }

            if ($request->type === 'national' && $request->hasFile('id_card_image')) {
                $documentImagePath = $request->file('id_card_image')->store('participants/documents', 'public');
            }

            if ($request->type === 'international' && $request->hasFile('passport_image')) {
                $documentImagePath = $request->file('passport_image')->store('participants/documents', 'public');
            }

            // Créer le participant
            $participant = Participant::create([
                'type' => $request->type,
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'email' => $request->email,
                'phone' => $request->phone,
                'date_of_birth' => $request->date_of_birth,
                'gender' => $request->gender,
                'country' => $request->country,
                'city' => $request->city,
                'address' => $request->address,
                'occupation' => $request->occupation,
                'organization' => $request->organization,
                'position' => $request->position,
                'motivation' => $request->motivation,
                'profile_image' => $profileImagePath,
                'id_card_image' => $request->type === 'national' ? $documentImagePath : null,
                'passport_image' => $request->type === 'international' ? $documentImagePath : null,
                'id_card_number' => $request->type === 'national' ? $request->id_card_number : null,
                'passport_number' => $request->type === 'international' ? $request->passport_number : null,
                'status' => 'pending',
                'email_confirmed' => false
            ]);

            // Envoyer l'email de confirmation
            $this->sendConfirmationEmail($participant);

            return response()->json([
                'success' => true,
                'message' => 'Inscription réussie ! Vérifiez votre email pour confirmer votre inscription.',
                'participant' => [
                    'unique_id' => $participant->unique_id,
                    'full_name' => $participant->full_name,
                    'email' => $participant->email,
                    'type' => $participant->type
                ]
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de l\'inscription: ' . $e->getMessage()
            ], 500);
        }
    }

    public function confirmEmail($token)
    {
        try {
            $participant = Participant::where('confirmation_token', $token)->first();

            if (!$participant) {
                return response()->json([
                    'success' => false,
                    'message' => 'Token de confirmation invalide'
                ], 404);
            }

            if ($participant->email_confirmed) {
                return response()->json([
                    'success' => false,
                    'message' => 'Email déjà confirmé'
                ], 400);
            }

            $participant->update([
                'email_confirmed' => true,
                'confirmed_at' => now(),
                'confirmation_token' => null
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Email confirmé avec succès !',
                'participant' => $participant
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la confirmation: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getParticipants(Request $request)
    {
        try {
            $query = Participant::query();

            // Filtres
            if ($request->has('type')) {
                $query->where('type', $request->type);
            }

            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('search')) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('first_name', 'like', "%{$search}%")
                      ->orWhere('last_name', 'like', "%{$search}%")
                      ->orWhere('email', 'like', "%{$search}%")
                      ->orWhere('unique_id', 'like', "%{$search}%");
                });
            }

            $participants = $query->orderBy('created_at', 'desc')
                                 ->paginate($request->get('per_page', 50));

            return response()->json([
                'success' => true,
                'participants' => $participants
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération: ' . $e->getMessage()
            ], 500);
        }
    }

    public function updateStatus(Request $request, $id)
    {
        try {
            $validator = Validator::make($request->all(), [
                'status' => 'required|in:pending,confirmed,rejected,badge_sent',
                'reason' => 'string|max:500'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors()
                ], 422);
            }

            $participant = Participant::findOrFail($id);
            $oldStatus = $participant->status;
            
            $participant->update([
                'status' => $request->status
            ]);

            // Envoyer un email selon le nouveau statut
            if ($request->status === 'confirmed' && $oldStatus !== 'confirmed') {
                $this->sendConfirmationStatusEmail($participant, 'confirmed');
            } elseif ($request->status === 'rejected' && $oldStatus !== 'rejected') {
                $this->sendConfirmationStatusEmail($participant, 'rejected', $request->reason);
            }

            return response()->json([
                'success' => true,
                'message' => 'Statut mis à jour avec succès',
                'participant' => $participant
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la mise à jour: ' . $e->getMessage()
            ], 500);
        }
    }

    public function sendBadge($id)
    {
        try {
            $participant = Participant::findOrFail($id);

            if (!$participant->canReceiveBadge()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Le participant doit être confirmé et avoir vérifié son email'
                ], 400);
            }

            // Générer le badge et la lettre d'invitation
            $this->generateAndSendBadge($participant);

            $participant->update(['status' => 'badge_sent']);

            return response()->json([
                'success' => true,
                'message' => 'Badge et lettre d\'invitation envoyés avec succès'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de l\'envoi: ' . $e->getMessage()
            ], 500);
        }
    }

    public function exportParticipants(Request $request)
    {
        try {
            $format = $request->get('format', 'excel'); // excel ou pdf
            $type = $request->get('type'); // national, international ou null pour tous

            $query = Participant::query();
            
            if ($type) {
                $query->where('type', $type);
            }

            $participants = $query->get();

            if ($format === 'pdf') {
                return $this->exportToPdf($participants);
            } else {
                return $this->exportToExcel($participants);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de l\'export: ' . $e->getMessage()
            ], 500);
        }
    }

    private function sendConfirmationEmail($participant)
    {
        try {
            $confirmationUrl = url("/confirm-email/{$participant->confirmation_token}");
            
            // Ici vous pouvez utiliser Mail::send() ou une API email comme SendGrid
            // Pour l'instant, on simule l'envoi et on log
            
            EmailLog::create([
                'participant_id' => $participant->id,
                'email_type' => 'confirmation',
                'email_subject' => 'Confirmez votre inscription - YouthConnekt Sahel 2025',
                'email_body' => "Bonjour {$participant->full_name}, cliquez sur ce lien pour confirmer: {$confirmationUrl}",
                'status' => 'sent'
            ]);

        } catch (\Exception $e) {
            \Log::error('Erreur envoi email confirmation: ' . $e->getMessage());
        }
    }

    private function sendConfirmationStatusEmail($participant, $status, $reason = null)
    {
        try {
            $subject = $status === 'confirmed' 
                ? 'Inscription confirmée - YouthConnekt Sahel 2025'
                : 'Inscription non retenue - YouthConnekt Sahel 2025';

            $body = $status === 'confirmed'
                ? "Félicitations {$participant->full_name} ! Votre inscription a été confirmée."
                : "Désolé {$participant->full_name}, votre inscription n'a pas été retenue. Raison: {$reason}";

            EmailLog::create([
                'participant_id' => $participant->id,
                'email_type' => $status === 'confirmed' ? 'confirmation' : 'rejection',
                'email_subject' => $subject,
                'email_body' => $body,
                'status' => 'sent'
            ]);

        } catch (\Exception $e) {
            \Log::error('Erreur envoi email statut: ' . $e->getMessage());
        }
    }

    private function generateAndSendBadge($participant)
    {
        // Ici vous intégreriez la génération de PDF pour le badge et la lettre
        // Pour l'instant on simule
        
        EmailLog::create([
            'participant_id' => $participant->id,
            'email_type' => 'badge',
            'email_subject' => 'Votre badge - YouthConnekt Sahel 2025',
            'email_body' => "Bonjour {$participant->full_name}, veuillez trouver en pièce jointe votre badge et lettre d'invitation.",
            'status' => 'sent'
        ]);
    }

    private function exportToExcel($participants)
    {
        // Implémentation de l'export Excel
        // Vous pouvez utiliser Laravel Excel ou PHPSpreadsheet
    }

    private function exportToPdf($participants)
    {
        // Implémentation de l'export PDF
        // Vous pouvez utiliser DomPDF ou TCPDF
    }
    
    /**
     * Get participant counts for dashboard
     */
    public function getCounts()
    {
        try {
            $total = Participant::count();
            $pending = Participant::where('status', 'pending')->count();
            $confirmed = Participant::where('status', 'confirmed')->count();
            $badgeSent = Participant::where('status', 'badge_sent')->count();
            $international = Participant::where('type', 'international')->count();
            
            return response()->json([
                'success' => true,
                'total' => $total,
                'pending' => $pending,
                'confirmed' => $confirmed,
                'badge_sent' => $badgeSent,
                'international' => $international
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Get dashboard statistics
     */
    public function getStats()
    {
        try {
            $stats = [
                'total' => Participant::count(),
                'confirmed' => Participant::where('status', 'confirmed')->count(),
                'pending' => Participant::where('status', 'pending')->count(),
                'rejected' => Participant::where('status', 'rejected')->count(),
                'badge_sent' => Participant::where('status', 'badge_sent')->count(),
                'national' => Participant::where('type', 'national')->count(),
                'international' => Participant::where('type', 'international')->count(),
                'email_confirmed' => Participant::where('email_confirmed', true)->count()
            ];
            
            return response()->json([
                'success' => true,
                'stats' => $stats
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Get chart data for dashboard
     */
    public function getCharts()
    {
        try {
            // Registration timeline (last 30 days)
            $registrationTimeline = $this->getRegistrationTimeline();
            
            // Type distribution
            $typeDistribution = [
                'national' => Participant::where('type', 'national')->count(),
                'international' => Participant::where('type', 'international')->count()
            ];
            
            return response()->json([
                'success' => true,
                'charts' => [
                    'registration_timeline' => $registrationTimeline,
                    'type_distribution' => $typeDistribution
                ]
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Get countries statistics
     */
    public function getCountriesStats()
    {
        try {
            $countries = Participant::select('country', \DB::raw('COUNT(*) as count'))
                ->groupBy('country')
                ->orderBy('count', 'desc')
                ->limit(10)
                ->get();
                
            return response()->json([
                'success' => true,
                'countries' => $countries
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Get registration timeline for chart
     */
    private function getRegistrationTimeline()
    {
        $days = 30;
        $timeline = [];
        
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = now()->subDays($i);
            $count = Participant::whereDate('created_at', $date->format('Y-m-d'))->count();
            
            $timeline['labels'][] = $date->format('d/m');
            $timeline['values'][] = $count;
        }
        
        return $timeline;
    }
}
