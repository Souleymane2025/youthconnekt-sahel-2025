<?php

namespace App\Http\Controllers;

use App\Models\Participant;
use Illuminate\Http\Request;

class ParticipantController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->validate([
            'first_name' => 'required|string|max:120',
            'last_name' => 'required|string|max:120',
            'email' => 'required|email|unique:participants,email',
            'phone' => 'nullable|string|max:60',
            'country' => 'required|string|max:120',
            'city' => 'required|string|max:120',
            'type' => 'nullable|string|max:120',
            'organization' => 'nullable|string|max:255',
            'occupation' => 'nullable|string|max:255',
            'experience' => 'nullable|string|max:1000',
            'motivation' => 'nullable|string|max:1000',
            'interests' => 'nullable|array',
            'interests.*' => 'string|max:120'
        ]);

        $participant = Participant::create($data + ['status' => 'pending']);
        return response()->json($participant, 201);
    }

    public function index(Request $request)
    {
        return Participant::latest()->paginate(50);
    }
}
