<?php
use Illuminate\Support\Facades\Route;
use App\Models\Blog;
use App\Models\Participant;
use App\Models\BlogMedia;
use App\Models\SiteAsset;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\ParticipantController;
use App\Http\Controllers\Api\ParticipantController as ApiParticipantController;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

// Blogs
Route::get('/blogs', fn() => Blog::with('media')->orderByDesc('created_at')->paginate(25));

Route::get('/blogs/{slug}', fn(string $slug) => Blog::with('media')->where('slug',$slug)->firstOrFail());

Route::post('/blogs', function(Request $request){
   $data = $request->validate([
      'title' => 'required|string|max:255',
      'category' => 'nullable|string|max:120',
      'content' => 'required|string',
      'status' => 'nullable|string|in:draft,published'
   ]);
   // Generate unique slug
   $baseSlug = Str::slug($data['title']);
   $slug = $baseSlug;
   $i = 2;
   while(Blog::where('slug',$slug)->exists()){
      $slug = $baseSlug.'-'.$i++;
   }
   $data['slug'] = $slug;
   $data['excerpt'] = Str::limit(strip_tags($data['content']), 180);
   $data['status'] = $data['status'] ?? 'draft';
   $data['author_name'] = 'Admin';
   $blog = Blog::create($data);
   return response()->json($blog, 201);
});

// Update blog (optionally regenerate slug)
Route::patch('/blogs/{slug}', function(Request $request, string $slug){
   $blog = Blog::where('slug',$slug)->firstOrFail();
   $data = $request->validate([
      'title' => 'sometimes|string|max:255',
      'category' => 'sometimes|nullable|string|max:120',
      'content' => 'sometimes|string',
      'status' => 'sometimes|string|in:draft,published',
      'regenerate_slug' => 'sometimes|boolean'
   ]);
   if(isset($data['title']) && ($request->boolean('regenerate_slug'))){
      $baseSlug = Str::slug($data['title']);
      $newSlug = $baseSlug; $i=2;
      while(Blog::where('slug',$newSlug)->where('id','!=',$blog->id)->exists()){
         $newSlug = $baseSlug.'-'.$i++;
      }
      $data['slug'] = $newSlug;
   }
   if(isset($data['content'])){
      $data['excerpt'] = Str::limit(strip_tags($data['content']), 180);
   }
   $blog->update($data);
   return $blog->fresh()->load('media');
});

// Upload multiple media files (images/videos) for a blog
Route::post('/blogs/{slug}/media', function(Request $request, string $slug){
   $blog = Blog::where('slug',$slug)->firstOrFail();
   $request->validate([
      'media' => 'required',
      'media.*' => 'file|mimes:jpeg,jpg,png,webp,gif,mp4,webm,mov,avi|max:51200', // 50MB per file
      'captions' => 'array',
      'captions.*' => 'nullable|string|max:255'
   ]);
   $files = $request->file('media');
   $saved = [];
   foreach($files as $i => $file){
      $mime = $file->getClientMimeType();
      $type = str_starts_with($mime, 'video') ? 'video' : 'image';
      $path = $file->store('blog_media','public');
      $media = $blog->media()->create([
         'type' => $type,
         'path' => $path,
         'mime_type' => $mime,
         'size' => $file->getSize(),
         'position' => $i,
         'caption' => $request->input('captions.' . $i),
      ]);
      $saved[] = $media;
   }
   return response()->json($saved, 201);
});

// Attach external media (e.g., YouTube video URL or remote image)
Route::post('/blogs/{slug}/media/external', function(Request $request, string $slug){
   $blog = Blog::where('slug',$slug)->firstOrFail();
   $data = $request->validate([
      'url' => 'required|url|max:2000',
      'type' => 'required|string|in:video,image,other',
      'caption' => 'nullable|string|max:255',
      'position' => 'nullable|integer'
   ]);
   $media = $blog->media()->create([
      'type' => $data['type'],
      'path' => $data['url'], // stored as direct URL
      'mime_type' => null,
      'size' => null,
      'position' => $data['position'] ?? ($blog->media()->max('position') + 1),
      'caption' => $data['caption'] ?? null,
      'meta' => ['external' => true]
   ]);
   return response()->json($media, 201);
});

// Delete a single media item
Route::delete('/blogs/{slug}/media/{mediaId}', function(string $slug, int $mediaId){
   $blog = Blog::where('slug',$slug)->firstOrFail();
   $media = $blog->media()->where('id',$mediaId)->firstOrFail();
   $media->delete();
   return response()->json(['deleted' => true]);
});

// Reorder media items
Route::patch('/blogs/{slug}/media/reorder', function(Request $request, string $slug){
   $blog = Blog::where('slug',$slug)->firstOrFail();
   $data = $request->validate([
      'order' => 'required|array',
      'order.*' => 'integer'
   ]);
   foreach($data['order'] as $pos => $id){
      BlogMedia::where('blog_id', $blog->id)->where('id',$id)->update(['position' => $pos]);
   }
   return $blog->load('media');
});

// ---------- Site Assets (logos, partner logos, sponsor logos, banners, gallery, etc.) ----------

// List assets (optionally filter by type)
Route::get('/assets', function(Request $request){
   $query = SiteAsset::query();
   if($t = $request->query('type')){ $query->where('type',$t); }
   if($request->boolean('active_only')){ $query->where('is_active', true); }
   return $query->orderBy('type')->orderBy('position')->paginate(50);
});

// Get single asset
Route::get('/assets/{id}', fn(int $id) => SiteAsset::findOrFail($id));

// Upload single asset
Route::post('/assets', function(Request $request){
   $data = $request->validate([
      'type' => 'required|string|max:60',
      'file' => 'required|file|mimes:jpeg,jpg,png,webp,gif,svg,ico,mp4,webm|max:51200',
      'alt' => 'nullable|string|max:255',
      'title' => 'nullable|string|max:255',
      'position' => 'nullable|integer',
      'exclusive' => 'nullable|boolean'
   ]);
   $file = $request->file('file');
   $path = $file->store('site_assets/'.$data['type'],'public');
   // If exclusive type (e.g., site_logo) -> deactivate previous
   if($request->boolean('exclusive')){
      SiteAsset::where('type',$data['type'])->update(['is_active' => false]);
   }
   $asset = SiteAsset::create([
      'type' => $data['type'],
      'path' => $path,
      'original_name' => $file->getClientOriginalName(),
      'mime_type' => $file->getClientMimeType(),
      'size' => $file->getSize(),
      'alt' => $data['alt'] ?? null,
      'title' => $data['title'] ?? null,
      'position' => $data['position'] ?? (SiteAsset::where('type',$data['type'])->max('position') + 1),
      'is_active' => true,
      'meta' => [ 'exclusive' => $request->boolean('exclusive') ]
   ]);
   return response()->json($asset, 201);
});

// Bulk upload multiple assets of same type
Route::post('/assets/bulk', function(Request $request){
   $data = $request->validate([
      'type' => 'required|string|max:60',
      'files' => 'required',
      'files.*' => 'file|mimes:jpeg,jpg,png,webp,gif,svg,ico,mp4,webm|max:51200'
   ]);
   $files = $request->file('files');
   $basePos = (int) SiteAsset::where('type',$data['type'])->max('position');
   $saved = [];
   foreach($files as $i => $file){
      $path = $file->store('site_assets/'.$data['type'],'public');
      $saved[] = SiteAsset::create([
         'type' => $data['type'],
         'path' => $path,
         'original_name' => $file->getClientOriginalName(),
         'mime_type' => $file->getClientMimeType(),
         'size' => $file->getSize(),
         'position' => $basePos + 1 + $i,
         'is_active' => true,
      ]);
   }
   return response()->json($saved, 201);
});

// Update meta / activate
Route::patch('/assets/{id}', function(Request $request, int $id){
   $asset = SiteAsset::findOrFail($id);
   $data = $request->validate([
      'alt' => 'sometimes|nullable|string|max:255',
      'title' => 'sometimes|nullable|string|max:255',
      'position' => 'sometimes|integer',
      'is_active' => 'sometimes|boolean'
   ]);
   // If activating and exclusive flag in meta -> deactivate siblings
   if(array_key_exists('is_active',$data) && $data['is_active'] && ($asset->meta['exclusive'] ?? false)){
      SiteAsset::where('type',$asset->type)->where('id','!=',$asset->id)->update(['is_active' => false]);
   }
   $asset->update($data);
   return $asset->fresh();
});

// Reorder assets for a type
Route::patch('/assets/reorder', function(Request $request){
   $data = $request->validate([
      'type' => 'required|string',
      'order' => 'required|array',
      'order.*' => 'integer'
   ]);
   foreach($data['order'] as $pos => $id){
      SiteAsset::where('type',$data['type'])->where('id',$id)->update(['position' => $pos]);
   }
   return SiteAsset::where('type',$data['type'])->orderBy('position')->get();
});

// Delete asset
Route::delete('/assets/{id}', function(int $id){
   $asset = SiteAsset::findOrFail($id);
   $asset->delete();
   return response()->json(['deleted' => true]);
});

Route::patch('/blogs/{slug}/publish', function(string $slug){
   $blog = Blog::where('slug',$slug)->firstOrFail();
   $blog->update(['status' => 'published', 'published_at' => now()]);
   return $blog;
});

Route::delete('/blogs/{slug}', function(string $slug){
   $blog = Blog::where('slug',$slug)->firstOrFail();
   $blog->delete();
   return response()->json(['deleted'=>true]);
});

// Participants API Routes
Route::prefix('participants')->group(function () {
    // Public routes
    Route::post('/register', [ApiParticipantController::class, 'register']);
    Route::get('/confirm-email/{token}', [ApiParticipantController::class, 'confirmEmail']);
    
    // Admin routes (you might want to add authentication middleware)
    Route::get('/', [ApiParticipantController::class, 'getParticipants']);
    Route::patch('/{id}/status', [ApiParticipantController::class, 'updateStatus']);
    Route::post('/{id}/send-badge', [ApiParticipantController::class, 'sendBadge']);
    Route::get('/export', [ApiParticipantController::class, 'exportParticipants']);
    
    // Dashboard data routes
    Route::get('/counts', [ApiParticipantController::class, 'getCounts']);
    Route::get('/stats', [ApiParticipantController::class, 'getStats']);
    Route::get('/charts', [ApiParticipantController::class, 'getCharts']);
    Route::get('/countries-stats', [ApiParticipantController::class, 'getCountriesStats']);
});

// Legacy participant routes (keeping for compatibility)
Route::post('/participants', [ParticipantController::class,'store']);
Route::get('/participants', [ParticipantController::class,'index']);
